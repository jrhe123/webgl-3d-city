from .interpo import scale, linearInterpo
'''
from .maths.kmeans1D import kmeans1d, getBreaks
from . import akima
from fillnodata import replace_nans
'''
